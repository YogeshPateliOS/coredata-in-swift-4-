//
//  Reg+CoreDataClass.swift
//  simpleCoreData
//
//  Created by Mac on 12/19/17.
//  Copyright © 2017 grras. All rights reserved.
//

import Foundation
import CoreData

@objc(Reg)
public class Reg: NSManagedObject {

}

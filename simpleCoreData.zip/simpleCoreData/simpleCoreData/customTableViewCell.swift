//
//  customTableViewCell.swift
//  simpleCoreData
//
//  Created by Mac on 12/19/17.
//  Copyright © 2017 grras. All rights reserved.
//

import UIKit

class customTableViewCell: UITableViewCell {

    
    @IBOutlet var lblUsername:UILabel!
    @IBOutlet var lblMobile:UILabel!
    @IBOutlet var lblEmail:UILabel!
    @IBOutlet var lblPassword:UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

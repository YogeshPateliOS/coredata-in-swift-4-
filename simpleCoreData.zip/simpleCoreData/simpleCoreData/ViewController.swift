//
//  ViewController.swift
//  simpleCoreData
//
//  Created by Mac on 12/19/17.
//  Copyright © 2017 grras. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{

    @IBOutlet var myTable:UITableView!
    
    
    @IBOutlet var txtUserName:UITextField!
    @IBOutlet var txtEmail:UITextField!
    @IBOutlet var txtMobile:UITextField!
    @IBOutlet var txtPassword:UITextField!
    
  
    var arrRegisterItems = [Reg]()
    var moc  :NSManagedObjectContext!
    //Access all object entire in an application
    var apDel  = UIApplication.shared.delegate as?  AppDelegate
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //step-2
        moc = apDel?.persistentContainer.viewContext
        myFucntion()
    }
    
    //step -4
    func myFucntion()
    {
        
        
        let registerRequest :NSFetchRequest<Reg> = Reg.fetchRequest()
        
        let desp1 = NSSortDescriptor(key: "username", ascending: false)
        let desp2 = NSSortDescriptor(key: "mobile", ascending: false)
         let desp3 = NSSortDescriptor(key: "email", ascending: false)
         let desp4 = NSSortDescriptor(key: "password", ascending: false)
        
        registerRequest.sortDescriptors = [desp1]
        registerRequest.sortDescriptors = [desp2]
        registerRequest.sortDescriptors = [desp3]
        registerRequest.sortDescriptors = [desp4]
        
        do
        {
             try arrRegisterItems =   moc.fetch(registerRequest)
        }
        catch
        {
            print("error")
        }
        //reload tableview here for display objects in tablview
        myTable.reloadData()
    }

    //Step - 3
    @IBAction func btnSaveClicked(sender:UIButton)
    {
        let main1 = Reg(context: moc)
        main1.username = txtUserName.text
        main1.email = txtEmail.text
        main1.mobile = txtMobile.text
        main1.password = txtPassword.text
        apDel?.saveContext()
        myFucntion()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrRegisterItems.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:customTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell")! as! customTableViewCell
        
        let mainItems = arrRegisterItems[indexPath.row]
        let types1 = mainItems.username
        cell.lblUsername.text = types1
        
        let types2 = mainItems.mobile
        cell.lblMobile.text = types2
        
        let types3 = mainItems.email
        cell.lblEmail.text = types3
        
        let types4 = mainItems.password
        cell.lblPassword.text = types4
        return cell
    }
    //Open tablview in editable mode...
   
    //Delete object using core data...
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let context:NSManagedObjectContext = self.moc
        
        if editingStyle == .delete
        {
            context.delete(arrRegisterItems[indexPath.row])
            let err:NSError! = nil
            
            do
            {
              try  context.save()
            }
            catch
            {
                print("error:::\(err.localizedDescription)")
                myTable.reloadData()
            }
            arrRegisterItems.remove(at: indexPath.row)
            myTable.deleteRows(at: [indexPath], with: UITableViewRowAnimation.fade)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


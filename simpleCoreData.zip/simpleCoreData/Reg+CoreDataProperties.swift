//
//  Reg+CoreDataProperties.swift
//  simpleCoreData
//
//  Created by Mac on 12/19/17.
//  Copyright © 2017 grras. All rights reserved.
//

import Foundation
import CoreData


extension Reg {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Reg> {
        return NSFetchRequest<Reg>(entityName: "Reg");
    }

    @NSManaged public var email: String?
    @NSManaged public var username: String?
    @NSManaged public var password: String?
    @NSManaged public var mobile: String?

}
